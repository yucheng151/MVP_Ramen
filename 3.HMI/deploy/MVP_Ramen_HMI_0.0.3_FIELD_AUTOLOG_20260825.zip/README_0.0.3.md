# MVP Ramen HMI 0.0.3

## 啟動方式

- 正式PLC：雙擊 `start_hmi.cmd`，預設 `192.168.1.5:502`。
- AS200 Simulator：先啟動COMMGR與AS200 Simulator，再雙擊 `start_hmi_as200_sim.cmd`，使用 `127.0.0.1:10002`。
- AS200即時碗流程：雙擊 `start_auto_live_monitor.cmd`，直接開啟AUTO流程監看頁。
- 完全不連PLC：雙擊 `start_hmi_mock.cmd`。

也可以從命令列指定：

```powershell
py main_hmi.py --ip 127.0.0.1 --port 10002
```

## 0.0.3新增功能

- AUTO SYSTEM獨立頁面。
- 訂單FIFO，每碗自動建立唯一UnitID。
- 訂單指定麵櫃1~10與軟／正常／硬三種熟度。
- 麵櫃1~10目前數量、容量、訂單保留量與可用量。
- 左上兩個空盒櫃目前數量與容量上限。
- 使用實際麵櫃圖片作為底圖，直接點選12個格位設定BOX數量。
- 三個麵篩狀態。
- 四站流程：落碗 → 放麵&UR1 → UR2 → 注湯&完成。
- PLC唯讀即時監看：FIFO、完成UnitID、三個麵篩State、最右端碗、UR與注湯狀態。
- D8100精確監看區完成後，可同時顯示四個站與三個麵篩各自的UnitID。
- 本機流程模擬，不寫入PLC。
- PLC通訊契約頁，未配置位址不會被HMI讀寫。
- HMI IP與Port都能由啟動參數指定。

## 本機資料

PLC自動通訊完成前，AUTO SYSTEM的設定會保存在：

`data/auto_hmi_state.json`

手機訂單API與PLC自動資料區完成後，將資料來源替換成正式通訊即可；畫面不需要重做。

## 自動模式運行 LOG

HMI會在自動模式記錄事件式診斷資料，不會每500 ms輪詢都重複寫入。記錄內容包含：

- Auto模式開始、結束與每60秒運行心跳。
- 訂單ACK、FIFO數量、完成Index與完成UnitID。
- 三個麵篩的State、UnitID與麵櫃編號變化。
- 四站UnitID與狀態變化。
- Nachi、UR1、UR2、輸送帶、感測器、注湯及異常狀態變化。
- PLC／IPC連線中斷與恢復。

Windows IPC的持久化位置：

`%LOCALAPPDATA%\MVP_Ramen_HMI\logs\auto`

每天同時產生：

- `auto_YYYY-MM-DD.jsonl`：後續程式與AI分析使用。
- `auto_YYYY-MM-DD.csv`：可直接使用Excel開啟。

預設保留90天。AUTO SYSTEM的「運行 LOG」分頁可查看最近250筆、開啟LOG資料夾或今日CSV。

## 已確認

- Python編譯與全部模組載入通過。
- FIFO、UnitID、庫存保留、完成扣庫存、資料重開保存通過。
- AS200 Simulator `127.0.0.1:10002` 連線、命令寫入與ACK通過。
- 目前PLC模擬程式對初始化回覆`ResponseCode=901`；通訊本身正常，待PLC初始化流程完成後再改為成功碼。
- 1366×768視覺檢查通過。

完整測試結果請見 `VALIDATION_REPORT_2026-08-19.md`。

介面與Mock功能可重新執行：

```powershell
py ..\..\8.TEST_Code\hmi_003_interface_test.py
```
