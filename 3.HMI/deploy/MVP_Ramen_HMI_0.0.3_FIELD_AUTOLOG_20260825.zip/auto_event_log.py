"""Structured, event-driven AUTO mode diagnostics for the HMI IPC.

The JSONL file is the canonical machine-readable record.  A matching CSV is
written at the same time so engineers can inspect the run directly in Excel.
Only changes and a periodic heartbeat are recorded; the 500 ms PLC polling
loop therefore does not flood the IPC disk.
"""

from __future__ import annotations

from collections import deque
import csv
from datetime import datetime, timedelta
import json
from pathlib import Path
import threading
import time
import uuid


CSV_FIELDS = (
    "timestamp", "session_id", "profile", "event_type", "component",
    "unit_id", "previous", "current", "details_json",
)


class AutoEventLog:
    def __init__(
        self,
        log_dir: Path | str,
        profile: str,
        retention_days: int = 90,
        heartbeat_seconds: float = 60.0,
    ) -> None:
        self.log_dir = Path(log_dir)
        try:
            self.log_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            # Keep the HMI operational if the Windows profile path is locked.
            self.log_dir = Path(__file__).resolve().parent / "logs" / "auto"
            self.log_dir.mkdir(parents=True, exist_ok=True)
        self.profile = profile
        self.retention_days = max(1, int(retention_days))
        self.heartbeat_seconds = max(10.0, float(heartbeat_seconds))
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:8]
        self._lock = threading.RLock()
        self._previous: dict | None = None
        self._auto_active = False
        self._last_heartbeat = 0.0
        self.last_error = ""
        self._cleanup_old_files()
        try:
            self._write_event(
                "LOGGER_START", "HMI",
                details={"retention_days": self.retention_days},
            )
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"

    def _paths(self, now: datetime | None = None) -> tuple[Path, Path]:
        day = (now or datetime.now()).strftime("%Y-%m-%d")
        return (
            self.log_dir / f"auto_{day}.jsonl",
            self.log_dir / f"auto_{day}.csv",
        )

    @property
    def current_jsonl_path(self) -> Path:
        return self._paths()[0]

    @property
    def current_csv_path(self) -> Path:
        return self._paths()[1]

    @staticmethod
    def _plain(value):
        if isinstance(value, dict):
            return {str(key): AutoEventLog._plain(item) for key, item in value.items()}
        if isinstance(value, (list, tuple, set)):
            return [AutoEventLog._plain(item) for item in value]
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        return str(value)

    @staticmethod
    def _normalize(snapshot: dict, alarms) -> dict:
        live = snapshot.get("auto_live") or {}
        robot = snapshot.get("robot")

        baskets = {}
        for basket in live.get("baskets", ()):
            no = str(basket.get("no", len(baskets) + 1))
            baskets[no] = {
                "state_no": basket.get("state_no"),
                "state": basket.get("state"),
                "unit_id": basket.get("unit_id"),
                "cabinet_no": basket.get("cabinet_no"),
                "exact": basket.get("exact"),
            }

        stations = {}
        for station in live.get("stations", ()):
            no = str(station.get("no", len(stations) + 1))
            stations[no] = {
                "name": station.get("name"),
                "state": station.get("state"),
                "unit_id": station.get("unit_id"),
                "exact": station.get("exact"),
            }

        robot_state = None
        if robot is not None:
            robot_state = {
                name: getattr(robot, name, None)
                for name in (
                    "read_complete", "action_complete", "index", "command_word",
                    "command_index", "action_no", "noodle_cabinet_no", "cut_no",
                    "output_cabinet_no", "noodle_type_no", "busy", "home_signal",
                    "error_signal", "alarm_signal", "estop_active", "program_running",
                    "plc_data_ready", "interval_motion_enable", "error_code",
                )
            }

        return {
            "online": bool(snapshot.get("online")),
            "heartbeat_ok": bool(snapshot.get("heartbeat_ok")),
            "machine_mode": int(
                live.get("machine_mode", snapshot.get("machine_mode", 0)) or 0
            ),
            "system": snapshot.get("system"),
            "conveyor_state": snapshot.get("conveyor_state"),
            "ack_index": snapshot.get("ack_index"),
            "response_code": snapshot.get("response_code"),
            "ipc_online": bool(snapshot.get("ipc_online")),
            "ipc_execution_status": snapshot.get("ipc_execution_status"),
            "fifo_count": live.get("fifo_count"),
            "ack_unit_id": live.get("ack_unit_id"),
            "ack_order_index": live.get("ack_index"),
            "order_response": live.get("order_response"),
            "complete_unit_id": live.get("complete_unit_id"),
            "complete_index": live.get("complete_index"),
            "rightmost_station": live.get("rightmost_station"),
            "head_unit_id": live.get("head_unit_id"),
            "soup_request_unit_id": live.get("soup_request_unit_id"),
            "soup_grant_unit_id": live.get("soup_grant_unit_id"),
            "soup_done_unit_id": live.get("soup_done_unit_id"),
            "ur1_done_unit_id": live.get("ur1_done_unit_id"),
            "ur2_done_unit_id": live.get("ur2_done_unit_id"),
            "cook_job_state": live.get("cook_job_state"),
            "noodle_action_step": live.get("noodle_action_step"),
            "ipc_action_step": live.get("ipc_action_step"),
            "head_bowl_state": live.get("head_bowl_state"),
            "head_job_state": live.get("head_job_state"),
            "noodle_action_flags": live.get("noodle_action_flags"),
            "auto_flow_flags": live.get("auto_flow_flags"),
            "active": AutoEventLog._plain(live.get("active") or {}),
            "baskets": baskets,
            "stations": stations,
            "sensors": AutoEventLog._plain(snapshot.get("sensors") or {}),
            "robot": robot_state,
            "alarms": sorted(str(item) for item in alarms),
            "mapping_source": live.get("source"),
            "mapping_precise": live.get("precise"),
        }

    @staticmethod
    def _unit_id(value) -> int | None:
        if isinstance(value, dict):
            candidate = value.get("unit_id")
        else:
            candidate = value
        try:
            candidate = int(candidate)
            return candidate if candidate > 0 else None
        except (TypeError, ValueError):
            return None

    def record_snapshot(self, snapshot: dict, alarms=()) -> None:
        """Record meaningful changes from one PLC/HMI snapshot."""
        try:
            with self._lock:
                current = self._normalize(snapshot, alarms)
                was_auto = self._auto_active
                is_auto = current["machine_mode"] == 2

                if is_auto and not was_auto:
                    self._auto_active = True
                    self._write_event(
                        "AUTO_SESSION_START", "MachineMode", previous=0, current=2,
                        details=current,
                    )
                    self._write_event("AUTO_SNAPSHOT", "Pipeline", details=current)
                    self._last_heartbeat = time.monotonic()
                elif was_auto and not is_auto:
                    self._write_event(
                        "AUTO_SESSION_END", "MachineMode", previous=2,
                        current=current["machine_mode"], details=current,
                    )
                    self._auto_active = False

                if self._previous is not None and (is_auto or was_auto):
                    self._record_changes(self._previous, current)

                if is_auto and time.monotonic() - self._last_heartbeat >= self.heartbeat_seconds:
                    self._write_event("AUTO_HEARTBEAT", "Pipeline", details=current)
                    self._last_heartbeat = time.monotonic()

                self._previous = current
                self.last_error = ""
        except Exception as exc:
            # Diagnostics must never interrupt the PLC polling thread.
            self.last_error = f"{type(exc).__name__}: {exc}"

    def _record_changes(self, previous: dict, current: dict) -> None:
        simple_events = {
            "online": ("PLC_CONNECTION", "PLC"),
            "heartbeat_ok": ("PLC_HEARTBEAT", "PLC"),
            "system": ("SYSTEM_STATE", "HMI"),
            "conveyor_state": ("CONVEYOR_STATE", "Conveyor"),
            "ipc_online": ("IPC_CONNECTION", "IPC"),
            "ipc_execution_status": ("IPC_STATE", "IPC"),
            "fifo_count": ("FIFO_CHANGE", "FIFO"),
            "rightmost_station": ("RIGHTMOST_CHANGE", "Conveyor"),
            "ack_index": ("COMMAND_ACK", "PLC"),
            "response_code": ("COMMAND_RESPONSE", "PLC"),
            "ack_unit_id": ("ORDER_ACK", "Order"),
            "ack_order_index": ("ORDER_ACK_INDEX", "Order"),
            "order_response": ("ORDER_RESPONSE", "Order"),
            "complete_unit_id": ("UNIT_COMPLETE", "Order"),
            "complete_index": ("COMPLETE_INDEX", "Order"),
            "head_unit_id": ("FIFO_HEAD_CHANGE", "FIFO"),
            "soup_request_unit_id": ("SOUP_REQUEST", "Soup"),
            "soup_grant_unit_id": ("SOUP_GRANT", "Soup"),
            "soup_done_unit_id": ("SOUP_DONE", "Soup"),
            "ur1_done_unit_id": ("UR1_DONE", "UR1"),
            "ur2_done_unit_id": ("UR2_DONE", "UR2"),
            "cook_job_state": ("COOK_JOB_STATE", "Scheduler"),
            "noodle_action_step": ("NOODLE_ACTION_STEP", "Nachi"),
            "ipc_action_step": ("IPC_ACTION_STEP", "IPC"),
            "head_bowl_state": ("HEAD_BOWL_STATE", "Conveyor"),
            "head_job_state": ("HEAD_JOB_STATE", "Scheduler"),
            "noodle_action_flags": ("NOODLE_ACTION_FLAGS", "Nachi"),
            "auto_flow_flags": ("AUTO_FLOW_FLAGS", "Scheduler"),
            "alarms": ("ALARM_CHANGE", "Alarm"),
            "mapping_source": ("MAPPING_SOURCE", "PLC"),
            "mapping_precise": ("MAPPING_PRECISION", "PLC"),
        }
        for key, (event_type, component) in simple_events.items():
            before, after = previous.get(key), current.get(key)
            if before != after:
                logged_event_type = event_type
                if key.endswith("unit_id") and self._unit_id(before) and not self._unit_id(after):
                    logged_event_type = f"{event_type}_CLEAR"
                self._write_event(
                    logged_event_type, component,
                    unit_id=self._unit_id(after) or self._unit_id(before),
                    previous=before, current=after,
                )

        for group, event_type, label in (
            ("baskets", "BASKET_CHANGE", "Basket"),
            ("stations", "STATION_CHANGE", "Station"),
        ):
            before_group = previous.get(group) or {}
            after_group = current.get(group) or {}
            for key in sorted(set(before_group) | set(after_group)):
                before, after = before_group.get(key), after_group.get(key)
                if before != after:
                    self._write_event(
                        event_type, f"{label}{key}",
                        unit_id=self._unit_id(after) or self._unit_id(before),
                        previous=before, current=after,
                    )

        for group, event_type, label in (
            ("active", "ACTION_CHANGE", "Action"),
            ("sensors", "SENSOR_CHANGE", "Sensor"),
        ):
            before_group = previous.get(group) or {}
            after_group = current.get(group) or {}
            for key in sorted(set(before_group) | set(after_group)):
                before, after = before_group.get(key), after_group.get(key)
                if before != after:
                    self._write_event(
                        event_type, f"{label}.{key}", previous=before, current=after,
                    )

        if previous.get("robot") != current.get("robot"):
            self._write_event(
                "ROBOT_STATE", "Nachi", previous=previous.get("robot"),
                current=current.get("robot"),
            )

    def _write_event(
        self,
        event_type: str,
        component: str,
        unit_id: int | None = None,
        previous=None,
        current=None,
        details: dict | None = None,
    ) -> None:
        now = datetime.now().astimezone()
        record = {
            "timestamp": now.isoformat(timespec="milliseconds"),
            "session_id": self.session_id,
            "profile": self.profile,
            "event_type": event_type,
            "component": component,
            "unit_id": unit_id,
            "previous": self._plain(previous),
            "current": self._plain(current),
            "details": self._plain(details or {}),
        }
        jsonl_path, csv_path = self._paths(now)
        with jsonl_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")

        new_csv = not csv_path.exists() or csv_path.stat().st_size == 0
        csv_encoding = "utf-8-sig" if new_csv else "utf-8"
        with csv_path.open("a", encoding=csv_encoding, newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
            if new_csv:
                writer.writeheader()
            writer.writerow({
                "timestamp": record["timestamp"],
                "session_id": record["session_id"],
                "profile": record["profile"],
                "event_type": record["event_type"],
                "component": record["component"],
                "unit_id": record["unit_id"] or "",
                "previous": json.dumps(record["previous"], ensure_ascii=False),
                "current": json.dumps(record["current"], ensure_ascii=False),
                "details_json": json.dumps(record["details"], ensure_ascii=False),
            })

    def read_recent(self, limit: int = 200) -> list[dict]:
        """Return recent events for the HMI log viewer."""
        rows: deque[dict] = deque(maxlen=max(1, int(limit)))
        with self._lock:
            files = sorted(self.log_dir.glob("auto_*.jsonl"))[-7:]
            for path in files:
                try:
                    with path.open("r", encoding="utf-8") as handle:
                        for line in handle:
                            try:
                                rows.append(json.loads(line))
                            except json.JSONDecodeError:
                                continue
                except OSError:
                    continue
        return list(rows)

    def close(self, snapshot: dict | None = None, alarms=()) -> None:
        with self._lock:
            details = self._normalize(snapshot, alarms) if snapshot else {}
            if self._auto_active:
                self._write_event("AUTO_SESSION_INTERRUPTED", "HMI", details=details)
                self._auto_active = False
            self._write_event("LOGGER_STOP", "HMI", details=details)

    def _cleanup_old_files(self) -> None:
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        for pattern in ("auto_*.jsonl", "auto_*.csv"):
            for path in self.log_dir.glob(pattern):
                try:
                    if datetime.fromtimestamp(path.stat().st_mtime) < cutoff:
                        path.unlink()
                except OSError:
                    continue


__all__ = ["AutoEventLog"]
