#!/usr/bin/env python3
"""Regression test for HMI AUTO-mode structured logging."""

from __future__ import annotations

from pathlib import Path
import sys
import tempfile


TEST_DIR = Path(__file__).resolve().parent
ROOT = TEST_DIR.parents[0]
HMI_DIR = (
    TEST_DIR
    if (TEST_DIR / "auto_event_log.py").exists()
    else ROOT / "3.HMI" / "0.0.3"
)
sys.path.insert(0, str(HMI_DIR))

from auto_event_log import AutoEventLog  # noqa: E402


def snapshot(mode=0, complete=0, fifo=0, basket_state=0, station_unit=None, online=True):
    return {
        "online": online,
        "heartbeat_ok": online,
        "machine_mode": mode,
        "system": "Normal" if online else "Alarm",
        "conveyor_state": "Ready" if online else "Unknown",
        "ack_index": 1,
        "response_code": 200,
        "ipc_online": online,
        "ipc_execution_status": "Idle" if online else "Offline",
        "sensors": {
            "bowl_drop_confirm": False,
            "pause_point_1": False,
            "pause_point_2": False,
            "right_stop_point": False,
        },
        "robot": None,
        "auto_live": {
            "machine_mode": mode,
            "fifo_count": fifo,
            "ack_unit_id": 1001 if mode == 2 else 0,
            "ack_order_index": 1,
            "complete_unit_id": complete,
            "complete_index": 1 if complete else 0,
            "rightmost_station": 20 if station_unit else 0,
            "head_unit_id": 1001 if fifo else 0,
            "soup_request_unit_id": 0,
            "soup_grant_unit_id": 0,
            "soup_done_unit_id": complete,
            "ur1_done_unit_id": complete,
            "ur2_done_unit_id": complete,
            "active": {
                "robot_idle": True,
                "noodle_busy": basket_state not in (0, 90),
                "ur1_active": False,
                "ur2_active": False,
            },
            "baskets": [
                {
                    "no": 1, "state_no": basket_state, "state": str(basket_state),
                    "unit_id": 1001 if basket_state else None,
                    "cabinet_no": 1 if basket_state else None, "exact": True,
                },
                {"no": 2, "state_no": 0, "state": "Idle", "unit_id": None,
                 "cabinet_no": None, "exact": True},
                {"no": 3, "state_no": 0, "state": "Idle", "unit_id": None,
                 "cabinet_no": None, "exact": True},
            ],
            "stations": [
                {"no": 1, "name": "落碗", "state": "Working" if station_unit else "Idle",
                 "unit_id": station_unit, "exact": True},
                {"no": 2, "name": "放麵與UR1", "state": "Idle", "unit_id": None,
                 "exact": True},
                {"no": 3, "name": "UR2", "state": "Idle", "unit_id": None,
                 "exact": True},
                {"no": 4, "name": "注湯與完成", "state": "Idle", "unit_id": None,
                 "exact": True},
            ],
            "source": "test",
            "precise": True,
        },
    }


def run() -> None:
    with tempfile.TemporaryDirectory() as temp:
        log = AutoEventLog(temp, profile="field", retention_days=90, heartbeat_seconds=60)
        log.record_snapshot(snapshot(mode=0))
        log.record_snapshot(snapshot(mode=2, fifo=1, basket_state=20, station_unit=1001))
        first_count = len(log.read_recent(1000))

        # An unchanged 500 ms poll must not create duplicate state events.
        log.record_snapshot(snapshot(mode=2, fifo=1, basket_state=20, station_unit=1001))
        assert len(log.read_recent(1000)) == first_count

        log.record_snapshot(snapshot(mode=2, fifo=0, basket_state=90, complete=1001))
        log.record_snapshot(snapshot(mode=2, fifo=0, basket_state=90, complete=1001,
                                     online=False), alarms=("PLC Communication Timeout",))
        log.record_snapshot(snapshot(mode=0, fifo=0, basket_state=0))
        log.close(snapshot(mode=0))

        rows = log.read_recent(1000)
        events = [row["event_type"] for row in rows]
        required = {
            "LOGGER_START", "AUTO_SESSION_START", "AUTO_SNAPSHOT",
            "BASKET_CHANGE", "STATION_CHANGE", "UNIT_COMPLETE",
            "PLC_CONNECTION", "ALARM_CHANGE", "AUTO_SESSION_END", "LOGGER_STOP",
        }
        missing = sorted(required - set(events))
        assert not missing, f"missing AUTO log events: {missing}"

        completed = [row for row in rows if row["event_type"] == "UNIT_COMPLETE"]
        assert completed and completed[-1]["unit_id"] == 1001
        assert log.current_jsonl_path.exists()
        assert log.current_csv_path.exists()
        assert "event_type" in log.current_csv_path.read_text(encoding="utf-8-sig").splitlines()[0]
        print(f"RESULT: PASS - {len(rows)} structured AUTO events written")
        print(f"JSONL: {log.current_jsonl_path}")
        print(f"CSV: {log.current_csv_path}")


if __name__ == "__main__":
    try:
        run()
    except Exception as exc:
        print(f"RESULT: FAIL - {type(exc).__name__}: {exc}")
        raise
