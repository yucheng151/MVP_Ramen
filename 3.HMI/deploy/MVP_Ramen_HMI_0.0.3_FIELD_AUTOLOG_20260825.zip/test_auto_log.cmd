@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: HMI environment is missing. Run setup_ipc.cmd first.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" test_auto_event_log.py
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" (
    echo AUTO event log test PASS.
) else (
    echo AUTO event log test FAIL. Error level: %RESULT%
)
pause
exit /b %RESULT%
